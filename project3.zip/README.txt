compile with make rwmain

run with ./a.out

scenarious.txt requires any sequence of
'r' and 'w' characters with a length of 10
any other length wont work